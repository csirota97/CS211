#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
	int check;
	int value;
} Node;

int hash(int);
